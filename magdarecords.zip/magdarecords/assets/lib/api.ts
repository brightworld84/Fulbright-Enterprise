export const fetchData = async (endpoint: string) => {
  const response = await fetch(`https://your-api.com/${endpoint}`);
  return response.json();
};
