import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertMedicalRecordSchema, 
  insertAiInsightSchema, 
  insertFileMetadataSchema,
  insertProviderSchema,
  type Provider
} from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import OpenAI from "openai";
import { 
  storeEncryptedFile, 
  retrieveEncryptedFile, 
  deleteEncryptedFile, 
  createEncryptedFileMetadata 
} from "./secure-storage";
import {
  processIncomingEmail,
  generateUserEmailAddress
} from "./email/email-service";

// Setup file uploads directory
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer storage
const storage_config = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (_req, file, cb) => {
    const uniqueFilename = `${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueFilename);
  },
});

const upload = multer({ 
  storage: storage_config,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (_req, file, cb) => {
    // Accept images, PDFs, and common document formats
    const validTypes = /jpeg|jpg|png|pdf|doc|docx|txt/;
    const isValid = validTypes.test(path.extname(file.originalname).toLowerCase());
    cb(null, isValid);
  }
});

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);

  // Handle validation errors
  const handleValidationError = (error: unknown, res: Response) => {
    if (error instanceof ZodError) {
      const validationError = fromZodError(error);
      return res.status(400).json({ 
        message: validationError.message,
        errors: error.errors
      });
    }
    return res.status(500).json({ message: "Internal server error" });
  };

  // Authentication middleware
  const authMiddleware = (req: Request, res: Response, next: Function) => {
    // Check if user is authenticated in session
    if (req.session && req.session.userId) {
      req.userId = req.session.userId;
      next();
    } else {
      res.status(401).json({ message: "Unauthorized" });
    }
  };

  // Authentication routes (no auth middleware required)
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { 
        username, 
        password, 
        firstName, 
        lastName, 
        dateOfBirth, 
        email,
        authProvider = "email"  // Default to email registration
      } = req.body;
      
      // Basic validation
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Hash the password (in a real app, use bcrypt)
      const hashedPassword = password; // would be hashed in production

      // Create the user with all fields
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        firstName,
        lastName,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : undefined,
        email,
        authProvider
      });

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Error registering user:", error);
      return res.status(500).json({ message: "Failed to register user" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, email, password } = req.body;
      
      // Either username or email must be provided
      if ((!username && !email) || !password) {
        return res.status(400).json({ message: "Username/email and password are required" });
      }

      // Find the user by username or email
      let user;
      if (username) {
        user = await storage.getUserByUsername(username);
      } else if (email) {
        // This assumes you have a getUserByEmail method in your storage
        // If not, you'll need to implement it or adapt the code
        user = await storage.getUserByEmail(email);
      }
      
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Verify password (in a real app, compare hashed passwords)
      if (user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Set user ID in session
      req.session.userId = user.id;
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;

      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Error logging in:", error);
      return res.status(500).json({ message: "Failed to log in" });
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    // Destroy the session
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to log out" });
      }
      return res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;

      return res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      return res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post("/api/auth/biometric", async (req: Request, res: Response) => {
    try {
      // In a real implementation, this would verify WebAuthn credentials
      // For now, we'll simulate a successful authentication with user ID 1
      
      // Check if the user has biometric auth enabled
      const user = await storage.getUser(1); // Using fixed user ID 1 for simulation
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Set user ID in session
      req.session.userId = user.id;
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;

      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Error with biometric authentication:", error);
      return res.status(500).json({ message: "Failed to authenticate" });
    }
  });

  // Social login endpoints
  app.post("/api/auth/social", async (req: Request, res: Response) => {
    try {
      const { provider, token, email, firstName, lastName } = req.body;
      
      if (!provider || !token || !email) {
        return res.status(400).json({ message: "Provider, token, and email are required" });
      }
      
      // In a real implementation, we would verify the token with the provider
      // Here we'll simulate the verification by just checking if the email exists
      
      // Find user by email
      let user = await storage.getUserByEmail(email);
      
      if (!user) {
        // Create new user if doesn't exist
        user = await storage.createUser({
          username: email.split('@')[0], // Use part of email as username
          password: null, // Password not used for social login
          email,
          firstName: firstName || null,
          lastName: lastName || null,
          authProvider: provider,
          externalId: token.substring(0, 20) // Just using part of the token as external ID
        });
      }
      
      // Set user ID in session
      req.session.userId = user.id;
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Error with social authentication:", error);
      return res.status(500).json({ message: "Failed to authenticate with social provider" });
    }
  });
  
  // Apply auth middleware to protected API routes
  app.use("/api/records", authMiddleware);
  app.use("/api/insights", authMiddleware);
  app.use("/api/providers", authMiddleware);
  app.use("/api/stats", authMiddleware);
  app.use("/api/analyze-all", authMiddleware);
  app.use("/api/fhir", authMiddleware);
  app.use("/api/email", authMiddleware);

  // Medical Record Routes
  app.get("/api/records", async (req: Request, res: Response) => {
    try {
      const records = await storage.getMedicalRecordsByUserId(req.userId);
      return res.json(records);
    } catch (error) {
      console.error("Error fetching records:", error);
      return res.status(500).json({ message: "Failed to fetch records" });
    }
  });

  app.get("/api/records/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid record ID" });
      }

      const record = await storage.getMedicalRecord(id);
      if (!record) {
        return res.status(404).json({ message: "Record not found" });
      }

      // Ensure user can only access their own records
      if (record.userId !== req.userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Get associated file metadata if exists
      const fileMetadata = await storage.getFileMetadataByRecordId(id);
      return res.json({ ...record, fileMetadata });
    } catch (error) {
      console.error("Error fetching record:", error);
      return res.status(500).json({ message: "Failed to fetch record" });
    }
  });

  app.post("/api/records", upload.single("file"), async (req: Request, res: Response) => {
    try {
      const recordData = insertMedicalRecordSchema.parse({
        ...req.body,
        userId: req.userId,
        recordDate: new Date(req.body.recordDate)
      });

      const newRecord = await storage.createMedicalRecord(recordData);

      // If file was uploaded, save its metadata
      if (req.file) {
        const fileData = {
          recordId: newRecord.id,
          originalName: req.file.originalname,
          storagePath: req.file.path,
          mimeType: req.file.mimetype,
          size: req.file.size
        };

        const fileMetadata = await storage.createFileMetadata(fileData);

        // If AI analysis is requested, process the file
        if (req.body.runAiAnalysis === "true" && process.env.OPENAI_API_KEY) {
          try {
            let aiSummary = "";
            
            // Process file content based on type
            if (req.file.mimetype.startsWith("image/")) {
              // For images, use vision model
              const imageBuffer = fs.readFileSync(req.file.path);
              const base64Image = imageBuffer.toString("base64");

              const visionResponse = await openai.chat.completions.create({
                model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
                messages: [
                  {
                    role: "system",
                    content: "You are a medical document analyzer. Extract and summarize key medical information from this document in a concise, clinically relevant manner. Format your response as a JSON object with 'summary' and 'keyValues' fields, where keyValues is an array of objects with 'name' and 'value' properties for important medical metrics."
                  },
                  {
                    role: "user",
                    content: [
                      {
                        type: "text",
                        text: "Analyze this medical document and extract important information:"
                      },
                      {
                        type: "image_url",
                        image_url: {
                          url: `data:${req.file.mimetype};base64,${base64Image}`
                        }
                      }
                    ],
                  },
                ],
                response_format: { type: "json_object" }
              });

              aiSummary = visionResponse.choices[0].message.content || "";
            } else {
              // For text-based documents, use text completion
              // In a real app, you'd use a document parser to extract text
              aiSummary = JSON.stringify({
                summary: "This is a medical document that contains patient health information.",
                keyValues: []
              });
            }

            // Update the record with AI analysis
            await storage.updateMedicalRecord(newRecord.id, {
              isAiProcessed: true,
              aiSummary
            });

            // Create an AI insight based on the analysis
            await storage.createAiInsight({
              userId: req.userId,
              title: "Analysis Complete",
              description: `AI analysis of your ${newRecord.title} is now available.`,
              relatedRecordId: newRecord.id
            });
          } catch (aiError) {
            console.error("Error during AI analysis:", aiError);
            // Continue without AI analysis if it fails
          }
        }

        return res.status(201).json({ ...newRecord, fileMetadata });
      }

      return res.status(201).json(newRecord);
    } catch (error) {
      console.error("Error creating record:", error);
      return handleValidationError(error, res);
    }
  });

  app.delete("/api/records/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid record ID" });
      }

      const record = await storage.getMedicalRecord(id);
      if (!record) {
        return res.status(404).json({ message: "Record not found" });
      }

      // Ensure user can only delete their own records
      if (record.userId !== req.userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Delete file if exists
      const fileMetadata = await storage.getFileMetadataByRecordId(id);
      if (fileMetadata) {
        try {
          fs.unlinkSync(fileMetadata.storagePath);
          await storage.deleteFileMetadata(fileMetadata.id);
        } catch (fileError) {
          console.error("Error deleting file:", fileError);
          // Continue with record deletion even if file deletion fails
        }
      }

      const deleted = await storage.deleteMedicalRecord(id);
      if (deleted) {
        return res.status(200).json({ message: "Record deleted successfully" });
      } else {
        return res.status(500).json({ message: "Failed to delete record" });
      }
    } catch (error) {
      console.error("Error deleting record:", error);
      return res.status(500).json({ message: "Failed to delete record" });
    }
  });

  // AI Insights Routes
  app.get("/api/insights", async (req: Request, res: Response) => {
    try {
      const insights = await storage.getAiInsightsByUserId(req.userId);
      return res.json(insights);
    } catch (error) {
      console.error("Error fetching insights:", error);
      return res.status(500).json({ message: "Failed to fetch insights" });
    }
  });

  app.post("/api/insights/dismiss/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid insight ID" });
      }

      const insight = await storage.getAiInsight(id);
      if (!insight) {
        return res.status(404).json({ message: "Insight not found" });
      }

      // Ensure user can only dismiss their own insights
      if (insight.userId !== req.userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const dismissed = await storage.dismissAiInsight(id);
      if (dismissed) {
        return res.status(200).json({ message: "Insight dismissed successfully" });
      } else {
        return res.status(500).json({ message: "Failed to dismiss insight" });
      }
    } catch (error) {
      console.error("Error dismissing insight:", error);
      return res.status(500).json({ message: "Failed to dismiss insight" });
    }
  });

  // Endpoint to run AI analysis on all user records
  app.post("/api/analyze-all", async (req: Request, res: Response) => {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(400).json({ message: "OpenAI API key not configured" });
    }

    try {
      const records = await storage.getMedicalRecordsByUserId(req.userId);
      
      if (records.length === 0) {
        return res.json({ message: "No records found to analyze" });
      }

      // Create a starting insight to inform the user
      const startInsight = await storage.createAiInsight({
        userId: req.userId,
        title: "AI Analysis Started",
        description: `Analysis started on ${records.length} medical record(s). You will be notified when complete.`,
        relatedRecordId: null
      });

      // Prepare record data for analysis
      const recordData = records.map(record => {
        return {
          id: record.id,
          title: record.title,
          recordType: record.recordType,
          provider: record.provider || 'Unknown provider',
          recordDate: record.recordDate.toISOString(), // Changed field name to match schema
          description: record.description || 'No description provided'
        };
      });

      // Use OpenAI to analyze the records
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: "You are a medical analysis assistant. Analyze the following medical records and provide insights about patterns, potential health concerns, and recommendations. Return results in JSON format with 'summary' and 'insights' array."
            },
            {
              role: "user",
              content: JSON.stringify(recordData)
            }
          ],
          response_format: { type: "json_object" }
        });

        // Parse the AI-generated insights
        if (response.choices[0]?.message?.content) {
          const analysisResult = JSON.parse(response.choices[0].message.content);
          
          // Create a general insight with the summary
          await storage.createAiInsight({
            userId: req.userId,
            title: "Health Summary",
            description: analysisResult.summary || "Analysis of your medical records complete.",
            relatedRecordId: null
          });

          // Add individual insights if available
          if (analysisResult.insights && Array.isArray(analysisResult.insights)) {
            for (const insight of analysisResult.insights.slice(0, 3)) { // Limit to 3 insights
              await storage.createAiInsight({
                userId: req.userId,
                title: insight.title || "Medical Insight",
                description: insight.description || "",
                relatedRecordId: insight.recordId || null
              });
            }
          }

          // Mark records as processed
          for (const record of records) {
            await storage.updateMedicalRecord(record.id, { isAiProcessed: true });
          }
        }
      } catch (aiError) {
        console.error("OpenAI analysis error:", aiError);
        
        // If AI fails, still provide a fallback insight
        await storage.createAiInsight({
          userId: req.userId,
          title: "Analysis Completed",
          description: "Your medical records have been reviewed. Please consult with your healthcare provider for professional advice.",
          relatedRecordId: null
        });
      }

      return res.json({ 
        message: "Analysis completed", 
        processedCount: records.length,
        insightId: startInsight.id
      });
    } catch (error) {
      console.error("Error during analysis:", error);
      return res.status(500).json({ message: "Failed to complete analysis" });
    }
  });

  // Statistics endpoint for dashboard
  app.get("/api/stats", async (req: Request, res: Response) => {
    try {
      const records = await storage.getMedicalRecordsByUserId(req.userId);
      const insights = await storage.getAiInsightsByUserId(req.userId);
      const providers = await storage.getProvidersByUserId(req.userId);
      
      // Get upcoming appointments (simulated)
      const upcomingCount = 2; // In a real app, this would be calculated from appointments data
      
      return res.json({
        recordCount: records.length,
        upcomingCount,
        insightCount: insights.length,
        providerCount: providers.length
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
      return res.status(500).json({ message: "Failed to fetch stats" });
    }
  });
  
  // Provider endpoints
  app.get("/api/providers", async (req: Request, res: Response) => {
    try {
      const providers = await storage.getProvidersByUserId(req.userId);
      return res.json(providers);
    } catch (error) {
      console.error("Error fetching providers:", error);
      return res.status(500).json({ message: "Failed to fetch providers" });
    }
  });
  
  app.get("/api/providers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid provider ID" });
      }
      
      const provider = await storage.getProvider(id);
      if (!provider) {
        return res.status(404).json({ message: "Provider not found" });
      }
      
      // Verify user has access to this provider
      if (provider.userId !== req.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      return res.json(provider);
    } catch (error) {
      console.error("Error fetching provider:", error);
      return res.status(500).json({ message: "Failed to fetch provider" });
    }
  });
  
  app.post("/api/providers", async (req: Request, res: Response) => {
    try {
      const validatedData = insertProviderSchema.parse({
        ...req.body,
        userId: req.userId
      });
      
      const provider = await storage.createProvider(validatedData);
      return res.status(201).json(provider);
    } catch (error) {
      handleValidationError(error, res);
      return res.status(500).json({ message: "Failed to create provider" });
    }
  });
  
  app.patch("/api/providers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid provider ID" });
      }
      
      const provider = await storage.getProvider(id);
      if (!provider) {
        return res.status(404).json({ message: "Provider not found" });
      }
      
      // Verify user has access to this provider
      if (provider.userId !== req.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updatedProvider = await storage.updateProvider(id, req.body);
      return res.json(updatedProvider);
    } catch (error) {
      handleValidationError(error, res);
      return res.status(500).json({ message: "Failed to update provider" });
    }
  });
  
  app.delete("/api/providers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid provider ID" });
      }
      
      const provider = await storage.getProvider(id);
      if (!provider) {
        return res.status(404).json({ message: "Provider not found" });
      }
      
      // Verify user has access to this provider
      if (provider.userId !== req.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      await storage.deleteProvider(id);
      return res.status(204).send();
    } catch (error) {
      console.error("Error deleting provider:", error);
      return res.status(500).json({ message: "Failed to delete provider" });
    }
  });
  
  // Email to Medical Record API Endpoints
  app.get("/api/email/address", async (req: Request, res: Response) => {
    try {
      // Generate a unique email address for this user
      const emailDomain = process.env.EMAIL_DOMAIN || "healthrecord.example.com";
      const userEmailAddress = generateUserEmailAddress(req.userId, emailDomain);
      
      return res.json({
        success: true,
        emailAddress: userEmailAddress,
        instructions: "Send your medical records to this email address. Attachments will be automatically added to your records."
      });
    } catch (error) {
      console.error("Error generating email address:", error);
      return res.status(500).json({ 
        success: false,
        message: "Could not generate email address for medical records" 
      });
    }
  });

  // This endpoint is for receiving webhook notifications from the email service
  app.post("/api/email/incoming", upload.single("email"), async (req: Request, res: Response) => {
    try {
      // Verify API key or secret (for security)
      const webhookSecret = req.headers['x-webhook-secret'];
      if (webhookSecret !== process.env.EMAIL_WEBHOOK_SECRET) {
        return res.status(403).json({ 
          success: false,
          message: "Invalid webhook secret" 
        });
      }
      
      // Extract user ID from the email address
      // In a real implementation, you would parse the recipient email to get the user ID
      const userId = parseInt(req.body.userId || "0");
      if (!userId) {
        return res.status(400).json({ 
          success: false,
          message: "Unable to determine user from email address" 
        });
      }
      
      // Process the email
      if (!req.file) {
        return res.status(400).json({ 
          success: false,
          message: "No email content provided" 
        });
      }
      
      const emailContent = fs.readFileSync(req.file.path);
      const result = await processIncomingEmail(emailContent, userId);
      
      // Clean up the temporary file
      fs.unlinkSync(req.file.path);
      
      if (!result.success) {
        return res.status(400).json({ 
          success: false,
          message: result.message
        });
      }
      
      return res.json({
        success: true,
        message: result.message,
        recordId: result.recordId
      });
    } catch (error) {
      console.error("Error processing incoming email:", error);
      return res.status(500).json({ 
        success: false,
        message: "Failed to process incoming email" 
      });
    }
  });
  
  // Endpoint to simulate sending medical records via email
  app.post("/api/email/simulate", upload.single("file"), async (req: Request, res: Response) => {
    try {
      // This endpoint simulates receiving an email with attachments
      // In a real implementation, this would be handled by the webhook endpoint above
      if (!req.file) {
        return res.status(400).json({ 
          success: false,
          message: "No file provided" 
        });
      }
      
      // Prepare email content in the format expected by processIncomingEmail
      // Here we're creating a simplified email structure with the uploaded file as an attachment
      const subject = req.body.subject || "Medical Record";
      const body = req.body.body || "Attached is a medical record for your records.";
      const provider = req.body.provider || "";
      
      // Read the uploaded file
      const fileContent = fs.readFileSync(req.file.path);
      
      // Create a simple email structure with the file as an attachment
      const email = `Subject: ${subject}\r\n\r\n${body}\r\n`;
      const emailWithAttachment = Buffer.concat([
        Buffer.from(email),
        Buffer.from(`--ATTACHMENT\r\nContent-Type: ${req.file.mimetype}\r\nContent-Disposition: attachment; filename="${req.file.originalname}"\r\n\r\n`),
        fileContent,
        Buffer.from("\r\n--ATTACHMENT--")
      ]);
      
      // Process the email
      const result = await processIncomingEmail(emailWithAttachment, req.userId);
      
      // Clean up the temporary file
      fs.unlinkSync(req.file.path);
      
      if (!result.success) {
        return res.status(400).json({ 
          success: false,
          message: result.message
        });
      }
      
      return res.json({
        success: true,
        message: "Successfully processed record from email simulation",
        recordId: result.recordId
      });
    } catch (error) {
      console.error("Error simulating email:", error);
      return res.status(500).json({ 
        success: false,
        message: "Failed to simulate email processing" 
      });
    }
  });
  
  // FHIR Integration API Endpoints
  
  // Import FHIR modules
  const { 
    getPatientData, 
    importPatientRecords, 
    extractProviderInformation 
  } = await import('./fhir/service');
  
  const { 
    requireFhirConnection, 
    checkFhirServerStatus 
  } = await import('./fhir/client');
  
  // Check FHIR server status
  app.get("/api/fhir/status/:provider", async (req: Request, res: Response) => {
    try {
      const providerType = req.params.provider as 'epic' | 'cerner' | 'allscripts';
      
      if (!['epic', 'cerner', 'allscripts'].includes(providerType)) {
        return res.status(400).json({ 
          success: false,
          message: "Invalid provider type. Must be one of: epic, cerner, allscripts" 
        });
      }
      
      const isConnected = await checkFhirServerStatus(providerType);
      
      return res.json({
        success: isConnected,
        provider: providerType,
        message: isConnected 
          ? `Connected to ${providerType} FHIR server` 
          : `Failed to connect to ${providerType} FHIR server`
      });
    } catch (error: any) {
      console.error("Error checking FHIR status:", error);
      return res.status(500).json({ 
        success: false,
        message: `Error checking FHIR status: ${error.message}` 
      });
    }
  });
  
  // Get patient data from FHIR server
  app.get("/api/fhir/patient/:provider/:patientId", 
    requireFhirConnection('epic'), // Default to Epic, middleware will check connection
    async (req: Request, res: Response) => {
      try {
        const providerType = req.params.provider as 'epic' | 'cerner' | 'allscripts';
        const patientId = req.params.patientId;
        
        if (!['epic', 'cerner', 'allscripts'].includes(providerType)) {
          return res.status(400).json({ 
            success: false, 
            message: "Invalid provider type" 
          });
        }
        
        if (!patientId) {
          return res.status(400).json({ 
            success: false, 
            message: "Patient ID is required" 
          });
        }
        
        const patientData = await getPatientData(providerType, patientId);
        
        if (!patientData) {
          return res.status(404).json({ 
            success: false, 
            message: "Patient not found" 
          });
        }
        
        return res.json({
          success: true,
          patient: patientData
        });
      } catch (error: any) {
        console.error("Error fetching patient data:", error);
        return res.status(500).json({ 
          success: false, 
          message: `Error fetching patient data: ${error.message}` 
        });
      }
    }
  );
  
  // Import patient records from FHIR server
  app.post("/api/fhir/import-records", async (req: Request, res: Response) => {
    try {
      const { providerType, patientId } = req.body;
      
      if (!providerType || !['epic', 'cerner', 'allscripts'].includes(providerType)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid provider type" 
        });
      }
      
      if (!patientId) {
        return res.status(400).json({ 
          success: false, 
          message: "Patient ID is required" 
        });
      }
      
      // Check connection first
      const isConnected = await checkFhirServerStatus(providerType);
      
      if (!isConnected) {
        return res.status(503).json({ 
          success: false, 
          message: `FHIR ${providerType} server connection is not available` 
        });
      }
      
      // Import records
      const result = await importPatientRecords(providerType, patientId, req.userId);
      
      return res.json({
        ...result,
        provider: providerType,
        patientId
      });
    } catch (error: any) {
      console.error("Error importing patient records:", error);
      return res.status(500).json({ 
        success: false, 
        message: `Error importing patient records: ${error.message}` 
      });
    }
  });
  
  // Extract provider information from FHIR
  app.post("/api/fhir/extract-provider", async (req: Request, res: Response) => {
    try {
      const { providerType, practitionerId } = req.body;
      
      if (!providerType || !['epic', 'cerner', 'allscripts'].includes(providerType)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid provider type" 
        });
      }
      
      if (!practitionerId) {
        return res.status(400).json({ 
          success: false, 
          message: "Practitioner ID is required" 
        });
      }
      
      // Check connection first
      const isConnected = await checkFhirServerStatus(providerType);
      
      if (!isConnected) {
        return res.status(503).json({ 
          success: false, 
          message: `FHIR ${providerType} server connection is not available` 
        });
      }
      
      // Extract provider information
      const provider = await extractProviderInformation(providerType, practitionerId, req.userId);
      
      if (!provider) {
        return res.status(404).json({ 
          success: false, 
          message: "Provider information could not be extracted" 
        });
      }
      
      return res.json({
        success: true,
        provider
      });
    } catch (error: any) {
      console.error("Error extracting provider information:", error);
      return res.status(500).json({ 
        success: false, 
        message: `Error extracting provider information: ${error.message}` 
      });
    }
  });
  
  // Demo data endpoint - only for development
  app.post("/api/demo-data", async (req: Request, res: Response) => {
    try {
      // Check if user already has records
      const existingRecords = await storage.getMedicalRecordsByUserId(req.userId);
      if (existingRecords.length > 0) {
        return res.status(400).json({ message: "Demo data already exists. Please delete existing records first." });
      }
      
      // Sample medical records for testing
      const demoRecords = [
        {
          userId: req.userId,
          title: "Blood Test Results",
          provider: "City General Hospital",
          recordType: "lab",
          recordDate: new Date(2023, 10, 15), // Nov 15, 2023
          description: "Complete blood count (CBC) showing normal white blood cell count and slightly elevated cholesterol levels. Doctor recommended dietary changes and follow-up in 6 months.",
          isAiProcessed: false
        },
        {
          userId: req.userId,
          title: "Annual Physical Examination",
          provider: "Dr. Sarah Johnson",
          recordType: "consultation",
          recordDate: new Date(2023, 9, 3), // Oct 3, 2023
          description: "Routine physical examination showing good overall health. Blood pressure: 120/80. Heart rate: 72 bpm. Weight: 155 lbs. Height: 5'10\". BMI: 22.3",
          isAiProcessed: false
        },
        {
          userId: req.userId,
          title: "Chest X-Ray",
          provider: "Radiology Partners",
          recordType: "imaging",
          recordDate: new Date(2023, 7, 22), // Aug 22, 2023
          description: "Chest X-ray performed due to persistent cough. Results show no abnormalities in the lungs or heart. Cough likely due to seasonal allergies.",
          isAiProcessed: false
        },
        {
          userId: req.userId,
          title: "Statin Prescription",
          provider: "City General Hospital Pharmacy",
          recordType: "medication",
          recordDate: new Date(2023, 11, 1), // Dec 1, 2023
          description: "Prescription for Atorvastatin 10mg, to be taken once daily with evening meal. 90-day supply with 3 refills. For management of high cholesterol.",
          isAiProcessed: false
        }
      ];
      
      // Sample providers for testing
      const demoProviders = [
        {
          userId: req.userId,
          name: "Dr. Sarah Johnson",
          specialty: "Family Medicine",
          facility: "Lakeside Medical Group",
          address: "123 Medical Plaza, Suite 202, Cityville, CA 90210",
          phone: "(555) 123-4567",
          email: "dr.johnson@lakesidemedical.example",
          notes: "Primary care physician since 2021",
          autoExtracted: false
        },
        {
          userId: req.userId,
          name: "City General Hospital",
          specialty: null,
          facility: "City General Hospital",
          address: "500 Hospital Drive, Cityville, CA 90210",
          phone: "(555) 867-5309",
          email: "info@citygeneral.example",
          notes: "Main hospital for emergency and specialized care",
          autoExtracted: false
        },
        {
          userId: req.userId,
          name: "Radiology Partners",
          specialty: "Diagnostic Imaging",
          facility: "Medical Arts Building",
          address: "400 Health Avenue, Cityville, CA 90210",
          phone: "(555) 234-5678",
          email: "admin@radiologypartners.example",
          notes: "Diagnostic imaging center with X-ray, MRI, and CT scanning services",
          autoExtracted: false
        }
      ];
      
      // Create each demo record
      const createdRecords = [];
      for (const record of demoRecords) {
        const newRecord = await storage.createMedicalRecord(record);
        createdRecords.push(newRecord);
      }
      
      // Create each demo provider
      const createdProviders = [];
      for (const provider of demoProviders) {
        const newProvider = await storage.createProvider(provider);
        createdProviders.push(newProvider);
      }
      
      return res.status(201).json({
        message: "Demo data created successfully",
        recordCount: createdRecords.length,
        providerCount: createdProviders.length,
        records: createdRecords,
        providers: createdProviders
      });
    } catch (error) {
      console.error("Error creating demo data:", error);
      return res.status(500).json({ message: "Failed to create demo data" });
    }
  });

  // Serve uploaded files
  app.get("/api/files/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid file ID" });
      }

      const fileMetadata = await storage.getFileMetadata(id);
      if (!fileMetadata) {
        return res.status(404).json({ message: "File not found" });
      }

      // Security check - ensure user owns the record associated with this file
      const record = await storage.getMedicalRecord(fileMetadata.recordId);
      if (!record || record.userId !== req.userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Verify file exists
      if (!fs.existsSync(fileMetadata.storagePath)) {
        return res.status(404).json({ message: "File not found on server" });
      }

      // Set content disposition for download
      res.setHeader('Content-Disposition', `inline; filename="${fileMetadata.originalName}"`);
      res.setHeader('Content-Type', fileMetadata.mimeType);
      
      // Stream the file to client
      const fileStream = fs.createReadStream(fileMetadata.storagePath);
      fileStream.pipe(res);
    } catch (error) {
      console.error("Error serving file:", error);
      return res.status(500).json({ message: "Failed to serve file" });
    }
  });

  // Extract provider information from a file using OpenAI
  app.post("/api/extract-provider", async (req: Request, res: Response) => {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(400).json({ message: "OpenAI API key not configured" });
    }

    try {
      const { fileId } = req.body;
      
      if (!fileId) {
        return res.status(400).json({
          success: false,
          message: "File ID is required"
        });
      }
      
      // Get the file metadata
      const fileMetadata = await storage.getFileMetadata(fileId);
      if (!fileMetadata) {
        return res.status(404).json({
          success: false,
          message: "File not found"
        });
      }
      
      // In a real application with the OpenAI API, we would:
      // 1. Get the file content
      // 2. Use OpenAI's GPT-4o to analyze the content and extract provider information
      // 3. Return the structured provider information
      
      // For demonstration purposes, we'll simulate the AI response
      // In production, this would use the actual OpenAI API with gpt-4o
      const simulatedProviderInfo = {
        name: `Dr. ${fileMetadata.originalName.split('.')[0]}`,
        specialty: "Family Medicine",
        facility: "Community Health Center",
        address: "123 Medical Plaza, Springfield, IL 62704",
        phone: "(555) 123-4567",
        email: `${fileMetadata.originalName.split('.')[0].toLowerCase()}@example.com`,
      };
      
      return res.status(200).json({
        success: true,
        providerInfo: simulatedProviderInfo
      });
    } catch (error) {
      console.error("Error extracting provider information:", error);
      return res.status(500).json({
        success: false,
        message: "Internal server error"
      });
    }
  });
