import { login } from '../lib/auth';

const handleLogin = async () => {
  const userData = await login(email, password);
  console.log(userData);
};

import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { FaApple, FaEnvelope } from "react-icons/fa";
import GoogleIcon from "@/components/icons/GoogleIcon";
import { motion } from "framer-motion";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, Fingerprint, Eye, EyeOff, Calendar } from "lucide-react";

// Form validation schemas
const loginSchema = z.object({
  username: z.string().min(6, {
    message: "Username must be at least 6 characters.",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }).refine(
    (password) => /\d/.test(password),
    {
      message: "Password must contain at least one number.",
    }
  ),
});

const emailLoginSchema = z.object({
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }).refine(
    (password) => /\d/.test(password),
    {
      message: "Password must contain at least one number.",
    }
  ),
});

const registerSchema = z.object({
  username: z.string().min(6, {
    message: "Username must be at least 6 characters.",
  }),
  firstName: z.string().min(1, {
    message: "First name is required.",
  }),
  lastName: z.string().min(1, {
    message: "Last name is required.",
  }),
  dateOfBirth: z.string().refine((val) => {
    const date = new Date(val);
    return !isNaN(date.getTime());
  }, {
    message: "Please enter a valid date of birth.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }).refine(
    (password) => /\d/.test(password),
    {
      message: "Password must contain at least one number.",
    }
  ),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type EmailLoginFormValues = z.infer<typeof emailLoginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export function LoginPage() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/login");
  const { toast } = useToast();
  const { loginWithSocial } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("login");
  const [loginMethod, setLoginMethod] = useState<"username" | "email">("username");
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);
  const [showRegisterConfirmPassword, setShowRegisterConfirmPassword] = useState(false);
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [biometricError, setBiometricError] = useState<string | null>(null);

  // Setup form for username login
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Setup form for email login
  const emailLoginForm = useForm<EmailLoginFormValues>({
    resolver: zodResolver(emailLoginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  // Setup form for registration
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      firstName: "",
      lastName: "",
      dateOfBirth: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (data: LoginFormValues) => {
      return apiRequest("POST", "/api/auth/login", data);
    },
    onSuccess: () => {
      toast({
        title: "Login successful",
        description: "Welcome back!",
        duration: 3000 // 3 seconds as requested
      });
      setLocation("/");
    },
    onError: (error: any) => {
      toast({
        title: "Login failed",
        description: error.message || "Invalid username or password",
        variant: "destructive",
        duration: 3000 // 3 seconds as requested
      });
    },
  });

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: async (data: RegisterFormValues) => {
      const { confirmPassword, ...userData } = data;
      return apiRequest("POST", "/api/auth/register", userData);
    },
    onSuccess: () => {
      toast({
        title: "Registration successful",
        description: "Your account has been created. You can now log in.",
        duration: 3000 // 3 seconds as requested
      });
      setActiveTab("login");
      registerForm.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Registration failed",
        description: error.message || "Unable to create account",
        variant: "destructive",
        duration: 3000 // 3 seconds as requested
      });
    },
  });

  // Biometric authentication function
  const handleBiometricAuth = async () => {
    try {
      setBiometricError(null);
      // Check if browser supports web authentication API
      if (!window.PublicKeyCredential) {
        setBiometricError("Your browser doesn't support biometric authentication");
        return;
      }

      // In a real implementation, we would:
      // 1. Request a challenge from the server
      // 2. Use the WebAuthn API to get credentials
      // 3. Verify the credentials with the server

      // For now, we'll simulate biometric authentication
      toast({
        title: "Biometric authentication",
        description: "Simulating Face ID/Touch ID. In a production app, this would use WebAuthn API.",
        duration: 3000 // 3 seconds as requested
      });

      // Simulate successful authentication after delay
      setTimeout(() => {
        toast({
          title: "Authentication successful",
          description: "Biometric verification complete",
          duration: 3000 // 3 seconds as requested
        });
        setLocation("/");
      }, 1500);
    } catch (error) {
      setBiometricError("Biometric authentication failed. Please try again or use password.");
    }
  };

  // Handle username login form submission
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };
  
  // Handle email login form submission
  const onEmailLoginSubmit = async (data: EmailLoginFormValues) => {
    try {
      await loginWithSocial({
        provider: 'email',
        token: 'simulated-email-token-' + Date.now(),
        email: data.email,
      });
      
      toast({
        title: "Email Login Successful",
        description: "You've been signed in with email",
        duration: 3000 // 3 seconds as requested
      });
      
      setLocation("/");
    } catch (error: any) {
      toast({
        title: "Login Failed",
        description: error.message || "Failed to authenticate with email",
        variant: "destructive",
        duration: 3000 // 3 seconds as requested
      });
    }
  };

  // Handle register form submission
  const onRegisterSubmit = (data: RegisterFormValues) => {
    registerMutation.mutate(data);
  };

  // Check if biometric authentication is available
  useEffect(() => {
    const checkBiometricAvailability = async () => {
      try {
        // Check if browser supports web authentication API
        if (window.PublicKeyCredential) {
          // Check if platform authenticator is available
          const available = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
          setBiometricAvailable(available);
        } else {
          setBiometricAvailable(false);
        }
      } catch (error) {
        setBiometricAvailable(false);
      }
    };

    checkBiometricAvailability();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4 py-12 sm:px-6 lg:px-8" role="main">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="mt-6 text-3xl font-bold text-primary">MediRecord</h1>
          <p className="mt-2 text-sm text-gray-600" id="app-description">Your secure medical records assistant</p>
        </div>

        <Tabs 
          value={activeTab} 
          onValueChange={setActiveTab} 
          className="w-full"
          aria-label="Authentication options"
        >
          <TabsList className="grid w-full grid-cols-2" aria-label="Authentication methods">
            <TabsTrigger value="login" aria-controls="login-tab" id="login-tab-trigger">Login</TabsTrigger>
            <TabsTrigger value="register" aria-controls="register-tab" id="register-tab-trigger">Register</TabsTrigger>
          </TabsList>

          {/* Login Tab */}
          <TabsContent value="login" className="mt-6" id="login-tab" aria-labelledby="login-tab-trigger">
            <Card>
              <CardHeader>
                <CardTitle>Welcome back</CardTitle>
                <CardDescription>
                  Login to access your medical records
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Social Login Buttons */}
                <div className="flex flex-col space-y-3 mb-6">
                  <div className="mb-2 text-center text-sm text-muted-foreground">
                    <p>Quick and secure login with your existing accounts</p>
                  </div>
                
                  <Button 
                    variant="outline" 
                    className="w-full flex items-center justify-center gap-2 hover:bg-red-50 transition-colors"
                    onClick={async () => {
                      try {
                        toast({
                          title: "Connecting to Google",
                          description: "Redirecting to Google authentication...",
                          duration: 3000 // 3 seconds as requested
                        });
                        
                        // For demo purposes, simulate a successful login after a brief delay
                        // In a real implementation, this would redirect to the Google OAuth flow
                        setTimeout(async () => {
                          await loginWithSocial({
                            provider: 'google',
                            token: 'google-auth-token-' + Date.now(),
                            email: 'user@gmail.com',
                            firstName: 'Demo',
                            lastName: 'User'
                          });
                          
                          toast({
                            title: "Google Sign In Successful",
                            description: "You've been signed in with Google",
                            duration: 3000 // 3 seconds as requested
                          });
                          
                          setLocation("/");
                        }, 800);
                      } catch (error: any) {
                        toast({
                          title: "Login Failed",
                          description: error.message || "Failed to authenticate with Google",
                          variant: "destructive",
                          duration: 3000 // 3 seconds as requested
                        });
                      }
                    }}
                    aria-label="Sign in with Google account"
                    data-testid="google-login-button"
                  >
                    <GoogleIcon size={18} aria-hidden="true" />
                    <span>Continue with Google</span>
                    <span className="sr-only">Sign in using your Google account</span>
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full flex items-center justify-center gap-2 hover:bg-neutral-50 transition-colors"
                    onClick={async () => {
                      try {
                        toast({
                          title: "Connecting to Apple",
                          description: "Redirecting to Apple authentication...",
                          duration: 3000 // 3 seconds as requested
                        });
                        
                        // For demo purposes, simulate a successful login after a brief delay
                        // In a real implementation, this would redirect to the Apple OAuth flow
                        setTimeout(async () => {
                          await loginWithSocial({
                            provider: 'apple',
                            token: 'apple-auth-token-' + Date.now(),
                            email: 'user@icloud.com',
                            firstName: 'Demo',
                            lastName: 'User'
                          });
                          
                          toast({
                            title: "Apple Sign In Successful",
                            description: "You've been signed in with Apple",
                            duration: 3000 // 3 seconds as requested
                          });
                          
                          setLocation("/");
                        }, 800);
                      } catch (error: any) {
                        toast({
                          title: "Login Failed",
                          description: error.message || "Failed to authenticate with Apple",
                          variant: "destructive",
                          duration: 3000 // 3 seconds as requested
                        });
                      }
                    }}
                    aria-label="Sign in with Apple account"
                    data-testid="apple-login-button"
                  >
                    <FaApple size={18} aria-hidden="true" />
                    <span>Continue with Apple</span>
                    <span className="sr-only">Sign in using your Apple account</span>
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full flex items-center justify-center gap-2 hover:bg-blue-50 transition-colors"
                    onClick={() => setLoginMethod("email")}
                    aria-label="Sign in with email"
                    data-testid="email-login-button"
                  >
                    <FaEnvelope size={18} className="text-blue-500" aria-hidden="true" />
                    <span>Continue with Email</span>
                    <span className="sr-only">Sign in using your email address</span>
                  </Button>
                  
                  <div className="text-xs text-center text-muted-foreground mt-2">
                    <p>By continuing, you agree to our <span className="text-primary cursor-pointer hover:underline">Terms of Service</span> and <span className="text-primary cursor-pointer hover:underline">Privacy Policy</span></p>
                  </div>
                </div>
                
                <div className="relative my-6">
                  <Separator />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="bg-white px-2 text-sm text-gray-500">or</span>
                  </div>
                </div>

                {/* Conditional Login Form based on loginMethod */}
                {loginMethod === "username" ? (
                  <>
                    {/* Username/Password Login Form */}
                    <Form {...loginForm}>
                      <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                        <FormField
                          control={loginForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Username</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your username" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={loginForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Password</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input 
                                    placeholder="Enter your password" 
                                    type={showLoginPassword ? "text" : "password"} 
                                    {...field} 
                                  />
                                  <button 
                                    type="button"
                                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
                                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                                  >
                                    {showLoginPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                  </button>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="submit" 
                          className="w-full mt-4"
                          disabled={loginMutation.isPending}
                        >
                          {loginMutation.isPending ? "Logging in..." : "Log In"}
                        </Button>
                      </form>
                    </Form>
                  </>
                ) : (
                  <>
                    {/* Email/Password Login Form */}
                    <Form {...emailLoginForm}>
                      <form onSubmit={emailLoginForm.handleSubmit(onEmailLoginSubmit)} className="space-y-4">
                        <FormField
                          control={emailLoginForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="Enter your email" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={emailLoginForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Password</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input 
                                    placeholder="Enter your password" 
                                    type={showLoginPassword ? "text" : "password"} 
                                    {...field} 
                                  />
                                  <button 
                                    type="button"
                                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
                                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                                  >
                                    {showLoginPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                  </button>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="flex justify-between">
                          <Button 
                            type="button" 
                            variant="ghost"
                            onClick={() => setLoginMethod("username")}
                            className="px-0"
                          >
                            Use username instead
                          </Button>
                          <Button 
                            type="submit" 
                            disabled={loginMutation.isPending}
                          >
                            {loginMutation.isPending ? "Logging in..." : "Log In"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </>
                )}

                {biometricAvailable && (
                  <>
                    <div className="relative my-6">
                      <Separator />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="bg-white px-2 text-sm text-gray-500">or</span>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      className="w-full flex items-center justify-center gap-2"
                      onClick={handleBiometricAuth}
                      aria-label="Log in with biometric authentication"
                      data-testid="biometric-login-button"
                    >
                      <Fingerprint size={18} aria-hidden="true" />
                      <span>Log in with Face ID / Touch ID</span>
                      <span className="sr-only">Sign in using biometric authentication like fingerprint or face recognition</span>
                    </Button>

                    {biometricError && (
                      <Alert variant="destructive" className="mt-4">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Authentication Error</AlertTitle>
                        <AlertDescription>{biometricError}</AlertDescription>
                      </Alert>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Register Tab */}
          <TabsContent value="register" className="mt-6" id="register-tab" aria-labelledby="register-tab-trigger">
            <Card>
              <CardHeader>
                <CardTitle>Create an account</CardTitle>
                <CardDescription>
                  Register to securely store and manage your medical records
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    {/* Personal Info Section */}
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={registerForm.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter first name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter last name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={registerForm.control}
                      name="dateOfBirth"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date of Birth</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input 
                                type="date" 
                                placeholder="MM/DD/YYYY" 
                                {...field} 
                              />
                              <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500" size={18} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input 
                              type="email" 
                              placeholder="Enter your email" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="Choose a username" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input 
                                placeholder="Create a password" 
                                type={showRegisterPassword ? "text" : "password"} 
                                {...field} 
                              />
                              <button 
                                type="button"
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
                                onClick={() => setShowRegisterPassword(!showRegisterPassword)}
                              >
                                {showRegisterPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                              </button>
                            </div>
                          </FormControl>
                          <FormDescription className="text-xs">
                            Password must be at least 6 characters
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input 
                                placeholder="Confirm your password" 
                                type={showRegisterConfirmPassword ? "text" : "password"} 
                                {...field} 
                              />
                              <button 
                                type="button"
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
                                onClick={() => setShowRegisterConfirmPassword(!showRegisterConfirmPassword)}
                              >
                                {showRegisterConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                              </button>
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full mt-4"
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? "Creating account..." : "Create Account"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
