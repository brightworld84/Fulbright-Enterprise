import { fetchData } from '../lib/api';
import { useEffect } from 'react';

useEffect(() => {
  fetchData('records').then(data => console.log(data));
}, []);

import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { 
  Card,
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  AlertTriangle, 
  CheckCircle2, 
  Download, 
  Search, 
  Server, 
  UserRound,
  Stethoscope
} from "lucide-react";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

type FHIRServerStatus = {
  success: boolean;
  provider: string;
  message: string;
};

type PatientData = {
  id: string;
  name: string;
  birthDate?: string;
  gender?: string;
};

export function FHIRIntegrationPage() {
  const { toast } = useToast();
  const [selectedProvider, setSelectedProvider] = useState<'epic' | 'cerner' | 'allscripts'>('epic');
  const [patientId, setPatientId] = useState('');
  const [practitionerId, setPractitionerId] = useState('');
  
  // Query to check server status
  const serverStatusQuery = useQuery({
    queryKey: ['fhir', 'status', selectedProvider],
    queryFn: async () => {
      const response = await apiRequest({ 
        url: `/api/fhir/status/${selectedProvider}`,
        method: 'GET',
        on401: 'throw'
      });
      return response as FHIRServerStatus;
    },
    enabled: !!selectedProvider,
    refetchInterval: 30000, // Refresh every 30 seconds
  });
  
  // Query to get patient data
  const patientQuery = useQuery({
    queryKey: ['fhir', 'patient', selectedProvider, patientId],
    queryFn: async () => {
      const response = await apiRequest({
        url: `/api/fhir/patient/${selectedProvider}/${patientId}`,
        method: 'GET',
        on401: 'throw'
      });
      return response as { success: boolean, patient: PatientData };
    },
    enabled: false, // Manually triggered
  });
  
  // Mutation to import patient records
  const importRecordsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest({
        url: '/api/fhir/import-records',
        method: 'POST',
        body: { providerType: selectedProvider, patientId },
        on401: 'throw'
      });
      return response as { success: boolean, count: number };
    },
    onSuccess: () => {
      toast({
        title: "Records Imported",
        description: "The patient records were successfully imported.",
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ['records'] });
    },
    onError: (error: any) => {
      toast({
        title: "Import Failed",
        description: error.message || "Failed to import patient records.",
        variant: "destructive"
      });
    }
  });
  
  // Mutation to extract provider information
  const extractProviderMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest({
        url: '/api/fhir/extract-provider',
        method: 'POST',
        body: { providerType: selectedProvider, practitionerId },
        on401: 'throw'
      });
      return response as { success: boolean };
    },
    onSuccess: () => {
      toast({
        title: "Provider Extracted",
        description: "Provider information was successfully extracted and saved.",
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ['providers'] });
      setPractitionerId('');
    },
    onError: (error: any) => {
      toast({
        title: "Extraction Failed",
        description: error.message || "Failed to extract provider information.",
        variant: "destructive"
      });
    }
  });
  
  // Handle search patient
  const handleSearchPatient = () => {
    if (!patientId) {
      toast({
        title: "Patient ID Required",
        description: "Please enter a valid patient ID.",
        variant: "destructive"
      });
      return;
    }
    
    patientQuery.refetch();
  };
  
  // Handle import records
  const handleImportRecords = () => {
    if (!patientId) {
      toast({
        title: "Patient ID Required",
        description: "Please enter a valid patient ID to import records.",
        variant: "destructive"
      });
      return;
    }
    
    importRecordsMutation.mutate();
  };
  
  // Handle provider extraction
  const handleExtractProvider = () => {
    if (!practitionerId) {
      toast({
        title: "Practitioner ID Required",
        description: "Please enter a valid practitioner ID.",
        variant: "destructive"
      });
      return;
    }
    
    extractProviderMutation.mutate();
  };
  
  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col space-y-2">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Healthcare Provider Integration</h1>
            <p className="text-muted-foreground">
              Connect with healthcare provider systems to import medical records and provider information.
            </p>
          </div>
          <div className="hidden md:flex space-x-2">
            <Button variant="outline" size="sm" asChild>
              <Link href="/">Home</Link>
            </Button>
            <Button variant="outline" size="sm" asChild>
              <Link href="/records">Records</Link>
            </Button>
            <Button variant="outline" size="sm" asChild>
              <Link href="/providers">Providers</Link>
            </Button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Server Status */}
        <Card className="md:col-span-3">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" /> Server Status
            </CardTitle>
            <CardDescription>
              Check connectivity with healthcare provider systems
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <div className="w-full max-w-xs">
                <Label htmlFor="server-select">Healthcare System</Label>
                <Select
                  value={selectedProvider}
                  onValueChange={(value) => setSelectedProvider(value as 'epic' | 'cerner' | 'allscripts')}
                >
                  <SelectTrigger className="mt-1 w-full">
                    <SelectValue placeholder="Select a provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectLabel>Provider Systems</SelectLabel>
                      <SelectItem value="epic">Epic Systems</SelectItem>
                      <SelectItem value="cerner">Cerner</SelectItem>
                      <SelectItem value="allscripts">Allscripts</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="mt-6 flex items-center">
                {serverStatusQuery.isLoading ? (
                  <Badge variant="outline" className="h-9 px-4 py-0 flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-yellow-500 animate-pulse"></div>
                    Checking connection...
                  </Badge>
                ) : serverStatusQuery.isError ? (
                  <Badge variant="destructive" className="h-9 px-4 py-0 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    Connection error
                  </Badge>
                ) : serverStatusQuery.data?.success ? (
                  <Badge variant="outline" className="bg-green-600 text-white h-9 px-4 py-0 flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4" />
                    Connected
                  </Badge>
                ) : (
                  <Badge variant="destructive" className="h-9 px-4 py-0 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    Disconnected
                  </Badge>
                )}
              </div>
              
              <div className="ml-auto mt-6">
                <Button onClick={() => serverStatusQuery.refetch()} variant="outline" size="sm">
                  Refresh Status
                </Button>
              </div>
            </div>
            
            {serverStatusQuery.isSuccess && !serverStatusQuery.data?.success && (
              <Alert variant="destructive" className="mt-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Connection Problem</AlertTitle>
                <AlertDescription>
                  {serverStatusQuery.data?.message || "Unable to connect to the selected healthcare system. Please check your credentials and network connection."}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
        
        {/* Integration Tabs */}
        <Card className="md:col-span-3">
          <CardHeader>
            <CardTitle>Healthcare Data Integration</CardTitle>
            <CardDescription>
              Search, view, and import healthcare data from connected systems
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="patients" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="patients">Patient Records</TabsTrigger>
                <TabsTrigger value="providers">Provider Information</TabsTrigger>
              </TabsList>
              
              {/* Patient Records Tab */}
              <TabsContent value="patients">
                <div className="space-y-4 py-2">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="w-full">
                      <Label htmlFor="patient-id">Patient ID</Label>
                      <div className="flex mt-1 gap-2">
                        <Input
                          id="patient-id"
                          placeholder="Enter patient identifier"
                          value={patientId}
                          onChange={(e) => setPatientId(e.target.value)}
                        />
                        <Button 
                          onClick={handleSearchPatient}
                          disabled={!patientId || patientQuery.isFetching}
                        >
                          <Search className="h-4 w-4 mr-2" />
                          Search
                        </Button>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Enter the patient's unique identifier in the selected system
                      </p>
                    </div>
                  </div>
                  
                  {patientQuery.isSuccess && (
                    <>
                      <Separator />
                      <div className="space-y-4">
                        <div className="flex items-center gap-2">
                          <UserRound className="h-5 w-5 text-primary" />
                          <h3 className="text-lg font-semibold">Patient Information</h3>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label className="text-muted-foreground">Name</Label>
                            <p className="font-medium">{patientQuery.data.patient.name}</p>
                          </div>
                          <div>
                            <Label className="text-muted-foreground">Patient ID</Label>
                            <p className="font-medium">{patientQuery.data.patient.id}</p>
                          </div>
                          {patientQuery.data.patient.birthDate && (
                            <div>
                              <Label className="text-muted-foreground">Date of Birth</Label>
                              <p className="font-medium">{new Date(patientQuery.data.patient.birthDate).toLocaleDateString()}</p>
                            </div>
                          )}
                          {patientQuery.data.patient.gender && (
                            <div>
                              <Label className="text-muted-foreground">Gender</Label>
                              <p className="font-medium capitalize">{patientQuery.data.patient.gender}</p>
                            </div>
                          )}
                        </div>
                        
                        <Button
                          onClick={handleImportRecords}
                          disabled={importRecordsMutation.isPending}
                          className="mt-4"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Import Medical Records
                        </Button>
                        
                        {importRecordsMutation.isPending && (
                          <p className="text-sm text-muted-foreground animate-pulse">
                            Importing records, please wait...
                          </p>
                        )}
                        
                        {importRecordsMutation.isSuccess && (
                          <Alert className="bg-green-50 border-green-200 text-green-800">
                            <CheckCircle2 className="h-4 w-4 text-green-600" />
                            <AlertTitle className="text-green-800">Import Successful</AlertTitle>
                            <AlertDescription className="text-green-700">
                              Successfully imported {importRecordsMutation.data?.count || "0"} medical records from {selectedProvider}.
                            </AlertDescription>
                          </Alert>
                        )}
                      </div>
                    </>
                  )}
                  
                  {patientQuery.isError && (
                    <Alert variant="destructive" className="mt-4">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>Patient Not Found</AlertTitle>
                      <AlertDescription>
                        Could not find patient with the provided ID in the {selectedProvider} system.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </TabsContent>
              
              {/* Provider Information Tab */}
              <TabsContent value="providers">
                <div className="space-y-4 py-2">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="w-full">
                      <Label htmlFor="practitioner-id">Practitioner ID</Label>
                      <div className="flex mt-1 gap-2">
                        <Input
                          id="practitioner-id"
                          placeholder="Enter practitioner identifier"
                          value={practitionerId}
                          onChange={(e) => setPractitionerId(e.target.value)}
                        />
                        <Button 
                          onClick={handleExtractProvider}
                          disabled={!practitionerId || extractProviderMutation.isPending}
                        >
                          <Stethoscope className="h-4 w-4 mr-2" />
                          Extract Provider
                        </Button>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Enter the healthcare provider's unique identifier to extract their information
                      </p>
                    </div>
                  </div>
                  
                  {extractProviderMutation.isPending && (
                    <p className="text-sm text-muted-foreground animate-pulse mt-4">
                      Extracting provider information, please wait...
                    </p>
                  )}
                  
                  {extractProviderMutation.isSuccess && (
                    <Alert className="bg-green-50 border-green-200 text-green-800 mt-4">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                      <AlertTitle className="text-green-800">Provider Information Extracted</AlertTitle>
                      <AlertDescription className="text-green-700">
                        Successfully added provider information to your contacts.
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  {extractProviderMutation.isError && (
                    <Alert variant="destructive" className="mt-4">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>Extraction Failed</AlertTitle>
                      <AlertDescription>
                        {extractProviderMutation.error?.message || "Could not extract provider information. Please verify the practitioner ID and try again."}
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="border-t bg-muted/50 px-6 py-3">
            <p className="text-xs text-muted-foreground">
              Data is securely transferred using FHIR protocols and stored with end-to-end encryption. No data is shared with third parties.
            </p>
          </CardFooter>
        </Card>
      </div>
      
      {/* Mobile navigation */}
      <div className="md:hidden flex justify-center mt-6 space-x-2">
        <Button variant="default" size="sm" asChild>
          <Link href="/">Home</Link>
        </Button>
        <Button variant="outline" size="sm" asChild>
          <Link href="/records">Records</Link>
        </Button>
        <Button variant="outline" size="sm" asChild>
          <Link href="/providers">Providers</Link>
        </Button>
      </div>
    </div>
  );
}