import { QueryClientProvider } from '@tanstack/react-query';
import queryClient from './lib/queryClient';
import { NavigationContainer } from '@react-navigation/native';

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <NavigationContainer>
        {/* Your app content */}
      </NavigationContainer>
    </QueryClientProvider>
  );
}

import { NavigationContainer } from '@react-navigation/native';
import Stack from './lib/navigation';

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        {/* Define your screens here */}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { MedicalRecordProvider } from "@/contexts/MedicalRecordContext";
import { EncryptionProvider } from "@/contexts/EncryptionContext";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { AccessibilityProvider } from "@/contexts/AccessibilityContext";
import { BottomNavigation } from "@/components/layout/BottomNavigation";
import { FloatingActionButton } from "@/components/layout/FloatingActionButton";
import { AddRecordModal } from "@/components/modals/AddRecordModal";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import RecordsPage from "@/pages/RecordsPage";
import AIPage from "@/pages/AIPage";
import ProfilePage from "@/pages/ProfilePage";
import { ProvidersPage } from "@/pages/ProvidersPage";
import { FHIRIntegrationPage } from "@/pages/FHIRIntegrationPage";
import { LoginPage } from "@/pages/LoginPage";
import { Loader2 } from "lucide-react";

// Protected route component that renders navigation UI when authenticated
function ProtectedRoute({ component: Component, ...rest }: { path?: string, component: React.ComponentType<any> }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/login" />;
  }

  return (
    <>
      <Component {...rest} />
    </>
  );
}

// Main application router
function Router() {
  const { user } = useAuth();
  
  return (
    <>
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route path="/">
          <ProtectedRoute component={HomePage} />
        </Route>
        <Route path="/records">
          <ProtectedRoute component={RecordsPage} />
        </Route>
        <Route path="/ai">
          <ProtectedRoute component={AIPage} />
        </Route>
        <Route path="/providers">
          <ProtectedRoute component={ProvidersPage} />
        </Route>
        <Route path="/integration">
          <ProtectedRoute component={FHIRIntegrationPage} />
        </Route>
        <Route path="/profile">
          <ProtectedRoute component={ProfilePage} />
        </Route>
        <Route>
          <NotFound />
        </Route>
      </Switch>
      
      {/* Only render these components when user is authenticated */}
      {user && (
        <>
          <BottomNavigation />
          <FloatingActionButton />
          <AddRecordModal />
        </>
      )}
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <EncryptionProvider>
          <MedicalRecordProvider>
            <AccessibilityProvider>
              {/* Skip to main content link for keyboard users */}
              <a href="#main-content" className="skip-link">
                Skip to main content
              </a>

              <div className="pb-16 relative min-h-screen" id="main-content"> 
                <Router />
              </div>
              <Toaster />
            </AccessibilityProvider>
          </MedicalRecordProvider>
        </EncryptionProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
